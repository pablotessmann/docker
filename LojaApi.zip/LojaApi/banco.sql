-- Passo 2: rode este script no phpMyAdmin do alwaysdata,
-- dentro do banco minhaconta_loja (aba SQL > Executar).

CREATE TABLE produtos (
  id    INT AUTO_INCREMENT PRIMARY KEY,
  nome  VARCHAR(100) NOT NULL,
  preco DECIMAL(10,2) NOT NULL
);

INSERT INTO produtos (nome, preco)
VALUES ('Caderno', 19.90),
       ('Caneta', 3.50);
