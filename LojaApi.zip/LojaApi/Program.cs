using MySqlConnector;

// ===== Passo 4: a base da API =====

var builder = WebApplication.CreateBuilder(args);

// lê a connection string da configuração
// (no Docker ela vem do arquivo .env, pela variável ConnectionStrings__Padrao)
var conexao = builder.Configuration
    .GetConnectionString("Padrao");

var app = builder.Build();

// ===== Passo 5: GET /produtos (listar do banco) =====

app.MapGet("/produtos", async () =>
{
    // 1. conectar no MySQL do alwaysdata
    await using var con = new MySqlConnection(conexao);
    await con.OpenAsync();

    // 2. consultar
    var cmd = new MySqlCommand(
        "SELECT id, nome, preco FROM produtos", con);
    await using var r = await cmd.ExecuteReaderAsync();

    // 3. montar a lista (0, 1 e 2 são as colunas do SELECT)
    var lista = new List<Produto>();
    while (await r.ReadAsync())
        lista.Add(new Produto(r.GetInt32(0),
            r.GetString(1), r.GetDecimal(2)));

    // 4. responder em JSON
    return lista;
});

// ===== Passo 6: POST /produtos (gravar no banco) =====

app.MapPost("/produtos", async (Produto p) =>
{
    await using var con = new MySqlConnection(conexao);
    await con.OpenAsync();

    // parâmetros (@nome, @preco) evitam SQL Injection
    var cmd = new MySqlCommand(
        "INSERT INTO produtos (nome, preco) " +
        "VALUES (@nome, @preco)", con);
    cmd.Parameters.AddWithValue("@nome", p.Nome);
    cmd.Parameters.AddWithValue("@preco", p.Preco);
    await cmd.ExecuteNonQueryAsync();

    // 201: registro criado
    return Results.Created();
});

app.Run();

// modelo: uma linha da tabela produtos
record Produto(int Id, string Nome, decimal Preco);
