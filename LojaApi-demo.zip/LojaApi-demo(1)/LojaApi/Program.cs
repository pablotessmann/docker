using MySqlConnector;

// ===== Passo 4: a base da API =====

var builder = WebApplication.CreateBuilder(args);

// lê a connection string da configuração
// (no Docker ela vem do arquivo .env, pela variável ConnectionStrings__Padrao)
var conexao = builder.Configuration
    .GetConnectionString("Padrao");

var app = builder.Build();

// ===== Diagnóstico: testa o banco ao iniciar e mostra o resultado no terminal =====

if (string.IsNullOrWhiteSpace(conexao))
{
    app.Logger.LogError(
        "Connection string vazia! Confira o arquivo .env (ConnectionStrings__Padrao=...).");
}
else
{
    try
    {
        await using var teste = new MySqlConnection(conexao);
        await teste.OpenAsync();
        app.Logger.LogInformation(
            "Conectado ao MySQL em {Servidor}, banco {Banco}.",
            teste.DataSource, teste.Database);
    }
    catch (Exception ex)
    {
        app.Logger.LogError("Falha ao conectar no MySQL: {Erro}", ex.Message);
    }
}

// página inicial: confirma que a API está no ar
app.MapGet("/", () =>
    "LojaApi rodando! Acesse /produtos para ver os produtos do banco.");

// ===== Passo 5: GET /produtos (listar do banco) =====

app.MapGet("/produtos", async () =>
{
    // 1. conectar no MySQL do alwaysdata
    await using var con = new MySqlConnection(conexao);
    await con.OpenAsync();

    // 2. consultar
    var cmd = new MySqlCommand(
        "SELECT id, nome, preco FROM Produto", con);
    await using var r = await cmd.ExecuteReaderAsync();

    // 3. montar a lista (0, 1 e 2 são as colunas do SELECT)
    var lista = new List<Produto>();
    while (await r.ReadAsync())
        lista.Add(new Produto(r.GetInt32(0),
            r.GetString(1), r.GetDecimal(2)));

    // 4. responder em JSON
    return lista;
});

// ===== Passo 6: POST /produtos (gravar no banco) =====

app.MapPost("/produtos", async (Produto p) =>
{
    await using var con = new MySqlConnection(conexao);
    await con.OpenAsync();

    // parâmetros (@nome, @preco) evitam SQL Injection
    var cmd = new MySqlCommand(
        "INSERT INTO Produto (nome, preco) " +
        "VALUES (@nome, @preco)", con);
    cmd.Parameters.AddWithValue("@nome", p.Nome);
    cmd.Parameters.AddWithValue("@preco", p.Preco);
    await cmd.ExecuteNonQueryAsync();

    // 201: registro criado
    return Results.Created();
});

app.Run();

// modelo: uma linha da tabela Produto
record Produto(int Id, string Nome, decimal Preco);
