# LojaApi: API C# no Docker com MySQL no alwaysdata

Demo da aula "Docker para iniciantes" (slides 14 a 24).
Uma API em C# (.NET 10) com duas rotas, `GET /produtos` e `POST /produtos`,
que roda num container Docker e grava os dados num MySQL online no alwaysdata.

```
Navegador / .http  →  Container Docker (LojaApi)  →  MySQL no alwaysdata
```

## O que você precisa

- [.NET 10 SDK](https://dotnet.microsoft.com/download) (só para rodar sem Docker)
- [Docker Desktop](https://www.docker.com/products/docker-desktop/) (no Windows, ele pede o WSL 2)
- Uma conta gratuita no [alwaysdata](https://www.alwaysdata.com)

## Arquivos do projeto

| Arquivo | Passo | Para que serve |
|---|---|---|
| `banco.sql` | 2 | Cria a tabela `produtos` e insere dois produtos |
| `LojaApi.csproj` | 3 | Projeto .NET 10 com o pacote `MySqlConnector` |
| `Program.cs` | 4 a 6 | A API: conexão, rota GET e rota POST |
| `.env` | 7 | A connection string com a senha (fora do Git) |
| `.env.example` | 7 | Modelo do `.env`, seguro para ir ao GitHub |
| `Dockerfile` | 8 | Monta a imagem em duas etapas |
| `.dockerignore` | 8 | Deixa `bin/`, `obj/` e `.env` fora da imagem |
| `compose.yaml` | 9 | Sobe o container e entrega o `.env` à API |
| `LojaApi.http` | 9 | Testes prontos de GET e POST |

## Passo a passo

### Passo 1: criar o banco no alwaysdata

1. Crie uma conta gratuita em alwaysdata.com.
2. No painel, abra **Databases › MySQL** e adicione um banco.
   O nome começa com o nome da conta, por exemplo `minhaconta_loja`.
3. Na aba **Users**, crie um usuário com senha e dê a ele permissão nesse banco.
4. Anote os dados de acesso:

| Dado | Exemplo |
|---|---|
| Host | `mysql-minhaconta.alwaysdata.net` |
| Porta | `3306` |
| Banco | `minhaconta_loja` |
| Usuário | `minhaconta_api` |
| Senha | a que você escolheu |

### Passo 2: criar a tabela

Em **Databases › MySQL**, abra o **phpMyAdmin**, entre no banco, clique na aba **SQL**,
cole o conteúdo de `banco.sql` e clique em **Executar**.

### Passo 3: projeto e driver

Este projeto já está pronto. Para criar do zero, os comandos são:

```bash
dotnet new webapi -n LojaApi
cd LojaApi
dotnet add package MySqlConnector
dotnet new gitignore
```

### Passos 4 a 6: o código

Está tudo no `Program.cs`, com comentários marcando cada passo.

### Passo 7: configurar a conexão

Abra o arquivo `.env` e troque `minhaconta`, o banco, o usuário e `SUA_SENHA` pelos seus dados.
A linha `ConnectionStrings__Padrao=...` precisa ficar **em uma linha só**.

> Os dois sublinhados (`__`) viram `:` para o .NET, que lê a chave `ConnectionStrings:Padrao`.

### Passos 8 e 9: rodar no Docker

Na pasta do projeto (onde estão o `Dockerfile` e o `compose.yaml`):

```bash
docker compose up --build
```

O terminal **fica preso mostrando os logs**: isso é normal, a API está no ar esperando requisições.
Procure as linhas:

```
Conectado ao MySQL em mysql-minhaconta.alwaysdata.net, banco minhaconta_loja.
Now listening on: http://[::]:8080
```

Se aparecer `Falha ao conectar no MySQL`, a mensagem logo depois diz o motivo (veja "Erros comuns").

Abra http://localhost:8080 para ver a mensagem de boas-vindas e
http://localhost:8080/produtos para ver o Caderno e a Caneta.

> Atenção: `docker compose build` só monta a imagem e não liga nada.
> Para ligar a API, use `docker compose up --build`.

Para testar o POST, abra o `LojaApi.http` no Visual Studio ou no VS Code (com a extensão REST Client)
e clique em **Send Request**. Rode o GET de novo: a Mochila aparece, vinda do alwaysdata.

Para desligar:

```bash
docker compose down
```

## Rodar sem Docker (opcional)

```bash
dotnet user-secrets init
dotnet user-secrets set "ConnectionStrings:Padrao" "Server=mysql-minhaconta.alwaysdata.net;Database=minhaconta_loja;User ID=minhaconta_api;Password=SUA_SENHA"
dotnet run
```

A API sobe em http://localhost:5080/produtos.

## Erros comuns

| Mensagem | O que fazer |
|---|---|
| `Unable to connect to any of the specified MySQL hosts` | Confira o host `mysql-SUACONTA.alwaysdata.net` e a internet |
| `Access denied for user` | Usuário ou senha errados, ou o usuário não tem permissão no banco |
| `Table '...produtos' doesn't exist` | Rode o `banco.sql` no banco certo |
| Erro dizendo que a ConnectionString está vazia | O `.env` não chegou à API: confira o `env_file` e os dois sublinhados |
| `port is already allocated` | A porta 8080 está em uso: troque para `"5080:8080"` no `compose.yaml` |

Para ver os logs do container: `docker compose logs api`.
Depois de mudar o `.env`, rode `docker compose up` de novo.
